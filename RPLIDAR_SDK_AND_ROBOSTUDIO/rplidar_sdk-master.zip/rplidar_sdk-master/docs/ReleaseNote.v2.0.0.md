RPLIDAR Public SDK v2.0.0 Release Note
======================================

- [new feature] Redesigned the skelton of the sdk
- [new feature] Support RPLIDAR-S2
- [improvement] 