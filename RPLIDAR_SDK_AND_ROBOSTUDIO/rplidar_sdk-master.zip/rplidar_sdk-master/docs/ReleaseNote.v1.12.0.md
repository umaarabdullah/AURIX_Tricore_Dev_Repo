RPLIDAR Public SDK v1.12.0 Release Note
======================================

- [new feature] support to set spin speed for S1 in rplidar_driver and framegrabber
- [improvement] use grabScanDataHq instead of grabScanData in ultra_simple